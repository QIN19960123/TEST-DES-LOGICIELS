void oracle_sort(
  int *Pre_table, int *table, 
  int Pre_l, int l)
{
  /* A remplacer */
  pathcrawler_verdict_unknown();
  return;
}
