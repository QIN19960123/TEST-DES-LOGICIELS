void oracle_search(
  int *Pre_A, int *A, 
  int Pre_elem, int elem, 
  int pathcrawler__retres__search)
{
  /* A remplacer */
  pathcrawler_verdict_unknown();
  
  return;
}
